/* SPDX-License-Identifier: GPL-2.0 */
#ifdef CONFIG_X86_32
# include <asm/mmzone_32.h>
#else
# include <asm/mmzone_64.h>
#endif
