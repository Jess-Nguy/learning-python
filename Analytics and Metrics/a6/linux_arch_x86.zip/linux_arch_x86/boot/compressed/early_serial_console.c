#include "misc.h"

int early_serial_base;

#include "../early_serial_console.c"
